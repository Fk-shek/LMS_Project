import { createContext, useContext, useEffect, useState, useCallback } from "react";
import { seedCourses } from "../data/courses";

const LMSContext = createContext(null);
export const useLMS = () => useContext(LMSContext);

function usePersisted(key, initial) {
  const [value, setValue] = useState(() => {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : initial;
    } catch {
      return initial;
    }
  });
  useEffect(() => {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch {
      /* ignore */
    }
  }, [key, value]);
  return [value, setValue];
}

export function LMSProvider({ children }) {
  const [courses, setCourses] = usePersisted("lms_courses", seedCourses);
  const [enrolled, setEnrolled] = usePersisted("lms_enrolled", []);
  const [completed, setCompleted] = usePersisted("lms_completed", {}); // {courseId: [lessonId]}
  const [results, setResults] = usePersisted("lms_results", {}); // {courseId: {score,total,date}}
  const [profile, setProfile] = usePersisted("lms_profile", {
    name: "Student User",
    email: "student@example.com",
    bio: "Lifelong learner.",
  });

  const getCourse = useCallback((id) => courses.find((c) => c.id === id), [courses]);
  const isEnrolled = (id) => enrolled.includes(id);
  const enroll = (id) => setEnrolled((e) => (e.includes(id) ? e : [...e, id]));
  const unenroll = (id) => setEnrolled((e) => e.filter((x) => x !== id));

  const isDone = (cid, lid) => (completed[cid] || []).includes(lid);
  const toggleLesson = (cid, lid) =>
    setCompleted((c) => {
      const cur = c[cid] || [];
      return { ...c, [cid]: cur.includes(lid) ? cur.filter((x) => x !== lid) : [...cur, lid] };
    });
  const markDone = (cid, lid) =>
    setCompleted((c) => {
      const cur = c[cid] || [];
      return cur.includes(lid) ? c : { ...c, [cid]: [...cur, lid] };
    });

  const progress = (cid) => {
    const course = courses.find((c) => c.id === cid);
    if (!course || !course.lessons.length) return 0;
    const done = (completed[cid] || []).filter((l) => course.lessons.some((x) => x.id === l)).length;
    return Math.round((done / course.lessons.length) * 100);
  };

  const saveResult = (cid, score, total) =>
    setResults((r) => ({ ...r, [cid]: { score, total, date: new Date().toISOString() } }));

  const addCourse = (course) => setCourses((c) => [...c, course]);
  const updateCourse = (course) => setCourses((c) => c.map((x) => (x.id === course.id ? course : x)));
  const deleteCourse = (id) => {
    setCourses((c) => c.filter((x) => x.id !== id));
    unenroll(id);
  };
  const resetData = () => {
    setCourses(seedCourses);
    setEnrolled([]);
    setCompleted({});
    setResults({});
  };

  return (
    <LMSContext.Provider
      value={{
        courses, getCourse, enrolled, isEnrolled, enroll, unenroll,
        completed, isDone, toggleLesson, markDone, progress,
        results, saveResult, profile, setProfile,
        addCourse, updateCourse, deleteCourse, resetData,
      }}
    >
      {children}
    </LMSContext.Provider>
  );
}
