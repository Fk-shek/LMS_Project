const mk = (cid, titles) =>
  titles.map((t, i) => ({
    id: `${cid}-l${i + 1}`,
    title: t,
    duration: `${8 + ((i * 3) % 9)} min`,
    content: `In this lesson, "${t}", you will learn the key ideas step by step, see practical examples, and finish with a short exercise to apply what you learned.`,
  }));

const q = (question, options, answer) => ({ question, options, answer });

export const seedCourses = [
  {
    id: "c1",
    title: "React Fundamentals",
    category: "Web Development",
    level: "Beginner",
    price: 0,
    rating: 4.8,
    image: "⚛️",
    description: "Learn components, props, state and hooks by building real UI.",
    instructor: { name: "Anita Rao", title: "Senior Frontend Engineer", bio: "10+ years building web apps and teaching React." },
    lessons: mk("c1", ["Introduction to React", "JSX and Components", "Props and State", "Handling Events", "Hooks: useEffect"]),
    quiz: [
      q("Which hook manages local state?", ["useEffect", "useState", "useRef", "useMemo"], 1),
      q("JSX stands for?", ["JavaScript XML", "Java Syntax Extension", "JSON XML", "JavaScript Extra"], 0),
      q("Props are…", ["Mutable", "Read-only inputs to a component", "Global state", "CSS rules"], 1),
    ],
  },
  {
    id: "c2",
    title: "Advanced JavaScript",
    category: "Web Development",
    level: "Intermediate",
    price: 49,
    rating: 4.6,
    image: "🟨",
    description: "Closures, async patterns, modules and the event loop explained.",
    instructor: { name: "Karthik S", title: "JS Architect", bio: "Speaker and open-source contributor." },
    lessons: mk("c2", ["Closures and Scope", "Promises and async/await", "Event Loop", "ES Modules"]),
    quiz: [
      q("Which keyword pauses an async function?", ["wait", "pause", "await", "yield"], 2),
      q("A closure is…", ["A loop", "A function remembering its outer scope", "A class", "A module"], 1),
    ],
  },
  {
    id: "c3",
    title: "UI/UX Design Basics",
    category: "Design",
    level: "Beginner",
    price: 29,
    rating: 4.5,
    image: "🎨",
    description: "Design principles, color, typography and prototyping basics.",
    instructor: { name: "Meera Iyer", title: "Product Designer", bio: "Designs for fintech and health products." },
    lessons: mk("c3", ["Design Principles", "Color Theory", "Typography", "Wireframing"]),
    quiz: [
      q("Which is a primary color in RGB?", ["Yellow", "Green", "Orange", "Purple"], 1),
      q("A wireframe is a…", ["Final design", "Low-fidelity layout", "Logo", "Animation"], 1),
    ],
  },
  {
    id: "c4",
    title: "Python for Data Analysis",
    category: "Data Science",
    level: "Intermediate",
    price: 59,
    rating: 4.7,
    image: "🐍",
    description: "Pandas, NumPy and visualization to analyze real datasets.",
    instructor: { name: "Dr. Vikram N", title: "Data Scientist", bio: "PhD in statistics, 8 years in industry." },
    lessons: mk("c4", ["Python Refresher", "NumPy Arrays", "Pandas DataFrames", "Plotting Data", "Cleaning Data"]),
    quiz: [
      q("Pandas main structure?", ["Tensor", "DataFrame", "Node", "Matrix only"], 1),
      q("NumPy is mainly for…", ["Web apps", "Numerical computing", "Databases", "Styling"], 1),
    ],
  },
  {
    id: "c5",
    title: "Digital Marketing 101",
    category: "Business",
    level: "Beginner",
    price: 0,
    rating: 4.2,
    image: "📈",
    description: "SEO, content, email and social media fundamentals.",
    instructor: { name: "Sana Khan", title: "Marketing Lead", bio: "Grew multiple D2C brands from zero." },
    lessons: mk("c5", ["Marketing Funnel", "SEO Basics", "Email Campaigns"]),
    quiz: [
      q("SEO stands for?", ["Search Engine Optimization", "Site Email Outreach", "Social Engine Ops", "Secure Edge Option"], 0),
    ],
  },
  {
    id: "c6",
    title: "Node.js & Express APIs",
    category: "Web Development",
    level: "Advanced",
    price: 69,
    rating: 4.9,
    image: "🟩",
    description: "Build and secure REST APIs with Node, Express and MongoDB.",
    instructor: { name: "Rahul Menon", title: "Backend Engineer", bio: "Builds scalable APIs for startups." },
    lessons: mk("c6", ["Node Basics", "Express Routing", "Middleware", "Auth with JWT"]),
    quiz: [
      q("Express is a…", ["Database", "Web framework", "Browser", "Compiler"], 1),
      q("JWT is used for…", ["Styling", "Authentication tokens", "Routing", "Testing"], 1),
    ],
  },
];

export const categories = ["All", ...new Set(seedCourses.map((c) => c.category))];
