import { Link } from "react-router-dom";
import { useLMS } from "../context/LMSContext";
import ProgressBar from "./ProgressBar";

export default function CourseCard({ course }) {
  const { isEnrolled, enroll, progress } = useLMS();
  const enrolled = isEnrolled(course.id);

  return (
    <div className="card course-card">
      <div className="thumb">{course.image}</div>
      <div className="card-body">
        <div className="tags">
          <span className="tag">{course.category}</span>
          <span className="tag alt">{course.level}</span>
        </div>
        <h3>{course.title}</h3>
        <p className="muted">{course.description}</p>
        <p className="meta">
          ⭐ {course.rating} · {course.lessons.length} lessons · {course.price ? `$${course.price}` : "Free"}
        </p>
        {enrolled && <ProgressBar value={progress(course.id)} />}
        <div className="row">
          <Link className="btn ghost" to={`/courses/${course.id}`}>Details</Link>
          {enrolled ? (
            <Link className="btn" to={`/courses/${course.id}/lessons/${course.lessons[0]?.id}`}>Continue</Link>
          ) : (
            <button className="btn" onClick={() => enroll(course.id)}>Enrol</button>
          )}
        </div>
      </div>
    </div>
  );
}
