import { Link } from "react-router-dom";

export default function LessonItem({ index, lesson, courseId, done, active, onToggle, locked }) {
  return (
    <li className={`lesson-item ${active ? "active" : ""}`}>
      <input
        type="checkbox"
        checked={done}
        disabled={locked}
        onChange={() => onToggle?.(lesson.id)}
        aria-label={`Mark ${lesson.title} complete`}
      />
      {locked ? (
        <span className="muted">{index + 1}. {lesson.title}</span>
      ) : (
        <Link to={`/courses/${courseId}/lessons/${lesson.id}`}>
          {index + 1}. {lesson.title}
        </Link>
      )}
      <span className="muted small">{lesson.duration}</span>
    </li>
  );
}
