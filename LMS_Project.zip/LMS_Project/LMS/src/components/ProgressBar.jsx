export default function ProgressBar({ value }) {
  return (
    <div className="progress" aria-label={`Progress ${value}%`}>
      <div className="progress-bar" style={{ width: `${value}%` }} />
      <span className="progress-label">{value}%</span>
    </div>
  );
}
