import { useState } from "react";
import { NavLink } from "react-router-dom";

const links = [
  ["/", "Dashboard"],
  ["/courses", "Catalogue"],
  ["/my-courses", "My Courses"],
  ["/profile", "Profile"],
  ["/admin", "Admin"],
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  return (
    <header className="navbar">
      <div className="brand">🎓 LearnHub</div>
      <button className="burger" onClick={() => setOpen(!open)} aria-label="Toggle menu">☰</button>
      <nav className={open ? "open" : ""} onClick={() => setOpen(false)}>
        {links.map(([to, label]) => (
          <NavLink key={to} to={to} end={to === "/"}>{label}</NavLink>
        ))}
      </nav>
    </header>
  );
}
