import { useState } from "react";
import { Link } from "react-router-dom";
import { useLMS } from "../context/LMSContext";
import CourseCard from "../components/CourseCard";

export default function MyCourses() {
  const { courses, enrolled, progress } = useLMS();
  const [tab, setTab] = useState("all");
  const mine = courses.filter((c) => enrolled.includes(c.id));
  const shown = mine.filter((c) => {
    const p = progress(c.id);
    return tab === "all" || (tab === "progress" && p < 100) || (tab === "done" && p === 100);
  });

  return (
    <>
      <h1>My Courses</h1>
      <div className="chips">
        {[["all", "All"], ["progress", "In progress"], ["done", "Completed"]].map(([k, l]) => (
          <button key={k} className={`chip ${tab === k ? "on" : ""}`} onClick={() => setTab(k)}>{l}</button>
        ))}
      </div>
      {shown.length === 0 ? (
        <div className="card pad">Nothing here yet. <Link to="/courses">Find a course</Link></div>
      ) : (
        <div className="grid">{shown.map((c) => <CourseCard key={c.id} course={c} />)}</div>
      )}
    </>
  );
}
