import { Link, useParams } from "react-router-dom";
import { useLMS } from "../context/LMSContext";
import LessonItem from "../components/LessonItem";
import ProgressBar from "../components/ProgressBar";

export default function CourseDetails() {
  const { courseId } = useParams();
  const { getCourse, isEnrolled, enroll, unenroll, isDone, toggleLesson, progress, results } = useLMS();
  const course = getCourse(courseId);
  if (!course) return <div className="card pad">Course not found. <Link to="/courses">Back</Link></div>;

  const enrolled = isEnrolled(course.id);
  const result = results[course.id];

  return (
    <>
      <Link to="/courses" className="muted">← Back to catalogue</Link>
      <div className="card pad hero">
        <div className="thumb big">{course.image}</div>
        <div style={{ flex: 1 }}>
          <div className="tags">
            <span className="tag">{course.category}</span>
            <span className="tag alt">{course.level}</span>
          </div>
          <h1>{course.title}</h1>
          <p>{course.description}</p>
          <p className="meta">⭐ {course.rating} · {course.lessons.length} lessons · {course.price ? `$${course.price}` : "Free"}</p>
          {enrolled && <ProgressBar value={progress(course.id)} />}
          <div className="row">
            {enrolled ? (
              <>
                <Link className="btn" to={`/courses/${course.id}/lessons/${course.lessons[0]?.id}`}>Start / Continue</Link>
                <Link className="btn ghost" to={`/courses/${course.id}/quiz`}>Take quiz</Link>
                <button className="btn danger" onClick={() => unenroll(course.id)}>Unenrol</button>
              </>
            ) : (
              <button className="btn" onClick={() => enroll(course.id)}>Enrol now</button>
            )}
          </div>
          {result && <p className="muted">Last quiz score: {result.score}/{result.total}</p>}
        </div>
      </div>

      <div className="two-col">
        <section className="card pad">
          <h2>Lessons</h2>
          <ul className="lessons">
            {course.lessons.map((l, i) => (
              <LessonItem
                key={l.id}
                index={i}
                lesson={l}
                courseId={course.id}
                done={isDone(course.id, l.id)}
                locked={!enrolled}
                onToggle={(lid) => toggleLesson(course.id, lid)}
              />
            ))}
          </ul>
          {!enrolled && <p className="muted small">Enrol to unlock lessons.</p>}
        </section>
        <aside className="card pad">
          <h2>Instructor</h2>
          <div className="avatar">{course.instructor.name[0]}</div>
          <h3>{course.instructor.name}</h3>
          <p className="muted">{course.instructor.title}</p>
          <p>{course.instructor.bio}</p>
        </aside>
      </div>
    </>
  );
}
