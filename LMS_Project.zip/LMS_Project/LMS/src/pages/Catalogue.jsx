import { useMemo, useState } from "react";
import { useLMS } from "../context/LMSContext";
import CourseCard from "../components/CourseCard";

export default function Catalogue() {
  const { courses } = useLMS();
  const [category, setCategory] = useState("All");
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState("title");

  const categories = useMemo(() => ["All", ...new Set(courses.map((c) => c.category))], [courses]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list = courses.filter(
      (c) =>
        (category === "All" || c.category === category) &&
        (!q || c.title.toLowerCase().includes(q) || c.description.toLowerCase().includes(q) || c.instructor.name.toLowerCase().includes(q))
    );
    const sorters = {
      title: (a, b) => a.title.localeCompare(b.title),
      rating: (a, b) => b.rating - a.rating,
      priceLow: (a, b) => a.price - b.price,
      priceHigh: (a, b) => b.price - a.price,
      lessons: (a, b) => b.lessons.length - a.lessons.length,
    };
    return [...list].sort(sorters[sort]);
  }, [courses, category, query, sort]);

  return (
    <>
      <h1>Course Catalogue</h1>
      <div className="toolbar">
        <input
          type="search"
          placeholder="Search courses, instructors…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <select value={sort} onChange={(e) => setSort(e.target.value)}>
          <option value="title">Sort: A–Z</option>
          <option value="rating">Sort: Top rated</option>
          <option value="priceLow">Sort: Price low → high</option>
          <option value="priceHigh">Sort: Price high → low</option>
          <option value="lessons">Sort: Most lessons</option>
        </select>
      </div>
      <div className="chips">
        {categories.map((c) => (
          <button key={c} className={`chip ${c === category ? "on" : ""}`} onClick={() => setCategory(c)}>
            {c}
          </button>
        ))}
      </div>
      {filtered.length === 0 ? (
        <p className="muted">No courses match your search.</p>
      ) : (
        <div className="grid">{filtered.map((c) => <CourseCard key={c.id} course={c} />)}</div>
      )}
    </>
  );
}
