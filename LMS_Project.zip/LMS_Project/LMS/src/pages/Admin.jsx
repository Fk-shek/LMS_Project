import { useState } from "react";
import { useLMS } from "../context/LMSContext";

const empty = {
  id: "", title: "", category: "", level: "Beginner", price: 0, rating: 4.5, image: "📘",
  description: "", instructorName: "", lessonTitles: "",
};

export default function Admin() {
  const { courses, addCourse, updateCourse, deleteCourse, resetData } = useLMS();
  const [form, setForm] = useState(empty);
  const editing = Boolean(form.id);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const edit = (c) =>
    setForm({
      id: c.id, title: c.title, category: c.category, level: c.level, price: c.price, rating: c.rating,
      image: c.image, description: c.description, instructorName: c.instructor.name,
      lessonTitles: c.lessons.map((l) => l.title).join("\n"),
    });

  const submit = (e) => {
    e.preventDefault();
    const id = form.id || `c${Date.now()}`;
    const existing = courses.find((c) => c.id === id);
    const titles = form.lessonTitles.split("\n").map((t) => t.trim()).filter(Boolean);
    const lessons = titles.map((t, i) => {
      const old = existing?.lessons[i];
      return old && old.title === t
        ? old
        : { id: old?.id || `${id}-l${i + 1}`, title: t, duration: "10 min", content: `Lesson content for "${t}".` };
    });
    const course = {
      id,
      title: form.title,
      category: form.category || "General",
      level: form.level,
      price: Number(form.price) || 0,
      rating: Number(form.rating) || 0,
      image: form.image || "📘",
      description: form.description,
      instructor: existing?.instructor
        ? { ...existing.instructor, name: form.instructorName }
        : { name: form.instructorName || "TBA", title: "Instructor", bio: "" },
      lessons,
      quiz: existing?.quiz || [],
    };
    editing ? updateCourse(course) : addCourse(course);
    setForm(empty);
  };

  return (
    <>
      <h1>Admin · Course Management</h1>
      <div className="two-col">
        <form className="card pad form" onSubmit={submit}>
          <h2>{editing ? "Edit course" : "Add course"}</h2>
          <label>Title<input required value={form.title} onChange={set("title")} /></label>
          <div className="row">
            <label style={{ flex: 1 }}>Category<input value={form.category} onChange={set("category")} /></label>
            <label style={{ flex: 1 }}>Level
              <select value={form.level} onChange={set("level")}>
                <option>Beginner</option><option>Intermediate</option><option>Advanced</option>
              </select>
            </label>
          </div>
          <div className="row">
            <label style={{ flex: 1 }}>Price ($)<input type="number" min="0" value={form.price} onChange={set("price")} /></label>
            <label style={{ flex: 1 }}>Rating<input type="number" min="0" max="5" step="0.1" value={form.rating} onChange={set("rating")} /></label>
            <label style={{ flex: 1 }}>Icon<input value={form.image} onChange={set("image")} /></label>
          </div>
          <label>Instructor<input required value={form.instructorName} onChange={set("instructorName")} /></label>
          <label>Description<textarea rows="2" value={form.description} onChange={set("description")} /></label>
          <label>Lessons (one title per line)<textarea required rows="4" value={form.lessonTitles} onChange={set("lessonTitles")} /></label>
          <div className="row">
            <button className="btn">{editing ? "Update" : "Add course"}</button>
            {editing && <button type="button" className="btn ghost" onClick={() => setForm(empty)}>Cancel</button>}
          </div>
        </form>

        <section className="card pad">
          <div className="row between">
            <h2>All courses ({courses.length})</h2>
            <button className="btn ghost" onClick={() => window.confirm("Reset all data to defaults?") && resetData()}>Reset data</button>
          </div>
          <table>
            <thead><tr><th>Title</th><th>Lessons</th><th></th></tr></thead>
            <tbody>
              {courses.map((c) => (
                <tr key={c.id}>
                  <td>{c.title}<br /><span className="muted small">{c.category}</span></td>
                  <td>{c.lessons.length}</td>
                  <td className="actions">
                    <button className="btn ghost sm" onClick={() => edit(c)}>Edit</button>
                    <button className="btn danger sm" onClick={() => window.confirm(`Delete "${c.title}"?`) && deleteCourse(c.id)}>Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>
      </div>
    </>
  );
}
