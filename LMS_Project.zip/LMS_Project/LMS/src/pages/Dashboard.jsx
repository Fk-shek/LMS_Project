import { Link } from "react-router-dom";
import { useLMS } from "../context/LMSContext";
import ProgressBar from "../components/ProgressBar";
import CourseCard from "../components/CourseCard";

export default function Dashboard() {
  const { courses, enrolled, progress, profile, completed, results } = useLMS();
  const mine = courses.filter((c) => enrolled.includes(c.id));
  const lessonsDone = Object.values(completed).reduce((n, a) => n + a.length, 0);
  const finished = mine.filter((c) => progress(c.id) === 100).length;
  const recommended = courses.filter((c) => !enrolled.includes(c.id)).slice(0, 3);

  return (
    <>
      <h1>Welcome back, {profile.name} 👋</h1>
      <div className="stats">
        <div className="card stat"><b>{mine.length}</b><span>Enrolled</span></div>
        <div className="card stat"><b>{lessonsDone}</b><span>Lessons done</span></div>
        <div className="card stat"><b>{finished}</b><span>Completed</span></div>
        <div className="card stat"><b>{Object.keys(results).length}</b><span>Quizzes taken</span></div>
      </div>

      <h2>Continue learning</h2>
      {mine.length === 0 ? (
        <div className="card pad">
          You haven't enrolled in any course yet. <Link to="/courses">Browse the catalogue</Link>
        </div>
      ) : (
        <div className="list">
          {mine.map((c) => (
            <div key={c.id} className="card pad row between">
              <div style={{ flex: 1 }}>
                <h3><Link to={`/courses/${c.id}`}>{c.title}</Link></h3>
                <ProgressBar value={progress(c.id)} />
              </div>
              <Link className="btn" to={`/courses/${c.id}/lessons/${c.lessons[0]?.id}`}>Resume</Link>
            </div>
          ))}
        </div>
      )}

      {recommended.length > 0 && (
        <>
          <h2>Recommended for you</h2>
          <div className="grid">{recommended.map((c) => <CourseCard key={c.id} course={c} />)}</div>
        </>
      )}
    </>
  );
}
