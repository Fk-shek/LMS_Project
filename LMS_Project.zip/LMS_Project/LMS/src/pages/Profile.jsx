import { useState } from "react";
import { useLMS } from "../context/LMSContext";

export default function Profile() {
  const { profile, setProfile, courses, enrolled, progress, results } = useLMS();
  const [form, setForm] = useState(profile);
  const [saved, setSaved] = useState(false);

  const mine = courses.filter((c) => enrolled.includes(c.id));
  const set = (k) => (e) => {
    setSaved(false);
    setForm({ ...form, [k]: e.target.value });
  };
  const save = (e) => {
    e.preventDefault();
    setProfile(form);
    setSaved(true);
  };

  return (
    <>
      <h1>My Profile</h1>
      <div className="two-col">
        <form className="card pad form" onSubmit={save}>
          <div className="avatar">{(form.name || "?")[0]}</div>
          <label>Name<input required value={form.name} onChange={set("name")} /></label>
          <label>Email<input required type="email" value={form.email} onChange={set("email")} /></label>
          <label>Bio<textarea rows="3" value={form.bio} onChange={set("bio")} /></label>
          <button className="btn">Save changes</button>
          {saved && <p className="ok">Profile updated ✓</p>}
        </form>

        <section className="card pad">
          <h2>Learning summary</h2>
          {mine.length === 0 ? (
            <p className="muted">No enrolled courses.</p>
          ) : (
            <table>
              <thead><tr><th>Course</th><th>Progress</th><th>Quiz</th></tr></thead>
              <tbody>
                {mine.map((c) => (
                  <tr key={c.id}>
                    <td>{c.title}</td>
                    <td>{progress(c.id)}%</td>
                    <td>{results[c.id] ? `${results[c.id].score}/${results[c.id].total}` : "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </section>
      </div>
    </>
  );
}
