import { useState } from "react";
import { Link, Navigate, useParams } from "react-router-dom";
import { useLMS } from "../context/LMSContext";

export default function Quiz() {
  const { courseId } = useParams();
  const { getCourse, isEnrolled, saveResult } = useLMS();
  const course = getCourse(courseId);
  const [answers, setAnswers] = useState({});
  const [submitted, setSubmitted] = useState(false);

  if (!course) return <div className="card pad">Course not found.</div>;
  if (!isEnrolled(course.id)) return <Navigate to={`/courses/${course.id}`} replace />;
  const quiz = course.quiz || [];
  if (!quiz.length) return <div className="card pad">No quiz for this course yet. <Link to={`/courses/${course.id}`}>Back</Link></div>;

  const score = quiz.reduce((n, q, i) => (answers[i] === q.answer ? n + 1 : n), 0);
  const pct = Math.round((score / quiz.length) * 100);
  const allAnswered = Object.keys(answers).length === quiz.length;

  const submit = () => {
    setSubmitted(true);
    saveResult(course.id, score, quiz.length);
  };
  const retry = () => {
    setAnswers({});
    setSubmitted(false);
  };

  return (
    <div className="card pad narrow">
      <Link to={`/courses/${course.id}`} className="muted">← {course.title}</Link>
      <h1>Quiz</h1>

      {submitted && (
        <div className={`result ${pct >= 60 ? "pass" : "fail"}`}>
          <h2>{score} / {quiz.length} ({pct}%)</h2>
          <p>{pct >= 60 ? "🎉 Great job, you passed!" : "Keep practising and try again."}</p>
        </div>
      )}

      {quiz.map((q, i) => (
        <fieldset key={i} className="question">
          <legend>{i + 1}. {q.question}</legend>
          {q.options.map((opt, oi) => {
            let cls = "option";
            if (submitted) {
              if (oi === q.answer) cls += " correct";
              else if (answers[i] === oi) cls += " wrong";
            } else if (answers[i] === oi) cls += " selected";
            return (
              <label key={oi} className={cls}>
                <input
                  type="radio"
                  name={`q${i}`}
                  disabled={submitted}
                  checked={answers[i] === oi}
                  onChange={() => setAnswers((a) => ({ ...a, [i]: oi }))}
                />
                {opt}
              </label>
            );
          })}
        </fieldset>
      ))}

      <div className="row">
        {!submitted ? (
          <button className="btn" disabled={!allAnswered} onClick={submit}>Submit answers</button>
        ) : (
          <>
            <button className="btn" onClick={retry}>Retry</button>
            <Link className="btn ghost" to="/my-courses">My courses</Link>
          </>
        )}
      </div>
      {!submitted && !allAnswered && <p className="muted small">Answer all questions to submit.</p>}
    </div>
  );
}
