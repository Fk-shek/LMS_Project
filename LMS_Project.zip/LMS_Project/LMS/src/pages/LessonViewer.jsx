import { Link, Navigate, useNavigate, useParams } from "react-router-dom";
import { useLMS } from "../context/LMSContext";
import LessonItem from "../components/LessonItem";
import ProgressBar from "../components/ProgressBar";

export default function LessonViewer() {
  const { courseId, lessonId } = useParams();
  const navigate = useNavigate();
  const { getCourse, isEnrolled, isDone, toggleLesson, markDone, progress } = useLMS();
  const course = getCourse(courseId);
  if (!course) return <div className="card pad">Course not found.</div>;
  if (!isEnrolled(course.id)) return <Navigate to={`/courses/${course.id}`} replace />;

  const idx = course.lessons.findIndex((l) => l.id === lessonId);
  if (idx === -1) return <Navigate to={`/courses/${course.id}`} replace />;

  const lesson = course.lessons[idx];
  const prev = course.lessons[idx - 1];
  const next = course.lessons[idx + 1];
  const done = isDone(course.id, lesson.id);

  const goNext = () => {
    markDone(course.id, lesson.id);
    navigate(next ? `/courses/${course.id}/lessons/${next.id}` : `/courses/${course.id}/quiz`);
  };

  return (
    <div className="two-col viewer">
      <section className="card pad">
        <Link to={`/courses/${course.id}`} className="muted">← {course.title}</Link>
        <p className="muted small">Lesson {idx + 1} of {course.lessons.length}</p>
        <h1>{lesson.title}</h1>
        <div className="video">▶ Video placeholder · {lesson.duration}</div>
        <p>{lesson.content}</p>
        <label className="check">
          <input type="checkbox" checked={done} onChange={() => toggleLesson(course.id, lesson.id)} />
          Mark as completed
        </label>
        <div className="row between">
          {prev ? (
            <Link className="btn ghost" to={`/courses/${course.id}/lessons/${prev.id}`}>← Previous</Link>
          ) : <span />}
          <button className="btn" onClick={goNext}>{next ? "Complete & Next →" : "Complete & Take Quiz →"}</button>
        </div>
      </section>
      <aside className="card pad">
        <h3>Course progress</h3>
        <ProgressBar value={progress(course.id)} />
        <ul className="lessons">
          {course.lessons.map((l, i) => (
            <LessonItem
              key={l.id}
              index={i}
              lesson={l}
              courseId={course.id}
              done={isDone(course.id, l.id)}
              active={l.id === lesson.id}
              onToggle={(lid) => toggleLesson(course.id, lid)}
            />
          ))}
        </ul>
      </aside>
    </div>
  );
}
